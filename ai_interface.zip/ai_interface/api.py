from flask import Flask
from flask import request
import openai

app = Flask(__name__)

@app.route("/call_gpt", methods=['POST'])
def call_gpt():
    if request.method == 'POST': 
        # msg = request.form['msg'] 
        data = request.get_json()
        msg = data['msg']  
        openai.api_key = 'your openai key'
        res = openai.Completion.create(
            model="gpt-3.5-turbo-instruct",
            prompt= msg,
            max_tokens=7,
            temperature=0
        ) 
        return res.choices[0].text 
    else:
        return 'error'

